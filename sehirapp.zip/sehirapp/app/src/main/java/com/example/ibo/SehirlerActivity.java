package com.example.ibo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SehirlerActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sehirler);

        Button istanbulButton = findViewById(R.id.istanbulButton);
        istanbulButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SehirlerActivity.this, IstanbulActivity.class);
                startActivity(intent);
            }
        });

        Button ankaraButton = findViewById(R.id.ankaraButton);
        ankaraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SehirlerActivity.this, AnkaraActivity.class);
                startActivity(intent);
            }
        });

        Button izmirButton = findViewById(R.id.izmirButton);
        izmirButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SehirlerActivity.this, IzmirActivity.class);
                startActivity(intent);
            }
        });
    }
}

