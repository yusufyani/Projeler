package com.example.testuygulamas;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BluetoothTestActivity extends AppCompatActivity {

    private TextView textBluetoothStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth_test);

        textBluetoothStatus = findViewById(R.id.textBluetoothStatus);
        Button btnCheckBluetooth = findViewById(R.id.btnCheckBluetooth);

        btnCheckBluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkBluetoothStatus();
            }
        });
    }

    private void checkBluetoothStatus() {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            textBluetoothStatus.setText("Cihaz Bluetooth'u desteklemiyor.");
        } else {
            if (bluetoothAdapter.isEnabled()) {
                textBluetoothStatus.setText("Bluetooth açık.");
            } else {
                textBluetoothStatus.setText("Bluetooth kapalı.");
            }
        }
    }
}

