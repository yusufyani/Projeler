package com.example.testuygulamas;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WifiTestActivity extends AppCompatActivity {

    private TextView textWifiStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_test);

        textWifiStatus = findViewById(R.id.textWifiStatus);
        Button btnCheckWifi = findViewById(R.id.btnCheckWifi);

        btnCheckWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkWifiStatus();
            }
        });
    }

    private void checkWifiStatus() {
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifiManager != null && wifiManager.isWifiEnabled()) {
            textWifiStatus.setText("Wi-Fi açık.");
        } else {
            textWifiStatus.setText("Wi-Fi kapalı.");
        }
    }
}

